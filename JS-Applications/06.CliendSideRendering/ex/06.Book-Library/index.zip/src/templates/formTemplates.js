import { html } from "../../../../../../node_modules/lit-html/lit-html.js";

export const loadButtonTemplate = () => html`
  <button id="loadBooks">LOAD ALL BOOKS</button>
`;