const url = `http://localhost:3030/jsonstore/collections/books`;

const tableBody = document.querySelector("tbody");

const form = document.querySelector("form");
form.addEventListener("submit", submitForm);

let formHeading = form.querySelector("h3");
let submitBtn = form.querySelector("button");

const loadBtn = document.getElementById("loadBooks");
loadBtn.addEventListener("click", handleLoadBooks);

function submitForm(ev) {
    ev.preventDefault();

    if (ev.currentTarget.querySelector("button").textContent === "Submit") {
        createBook(ev);
    } else {
        editBook(ev);
    }
}

function createBook(e) {
    let formData = new FormData(form);

    let title = formData.get("title");
    let author = formData.get("author");

    if (!title || !author) {
        return alert("Invalid input.");
    }

    const bookObj = {
        author,
        title,
    };

    const options = {
        method: "POST",
        headers: {
            "content-type": "application/json",
        },
        body: JSON.stringify(bookObj),
    };

    fetch(url, options)
        .then((res) => {
            if (res.status !== 200) {
                throw new Error("Wrong status code!");
            }

            //clear the input fields
            e.target.reset();

            //load the books
            handleLoadBooks();
        })
        .catch((err) => {
            console.log(err);
        });
}

function editBook(ev) {
    
    const formData = new FormData(ev.target);

    let title = formData.get('title');
    let author = formData.get('author');

    if(!title || !author){
        return alert('Invalid input.');
    }

    const bookObj = {
        author,
        title
    }

    fetch(`${url}/${form.id}`, {
        method: 'PUT',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(bookObj)
    })
        .then(() => {

            ev.target.reset();

            submitBtn.textContent = 'FORM';
            formHeading.textContent = 'Submit';

            form.id = '';

            handleLoadBooks();
        })
        .catch((err) => {
            console.log(err);
        })

}

function handleLoadBooks() {
    fetch(url)
        .then((res) => {
            if (res.status !== 200) {
                throw new Error("Wrong status code!");
            }

            return res.json();
        })
        .then((data) => {
            tableBody.textContent = "";

            Object.entries(data).map((book) => {
                let id = book[0];
                let { author, title } = book[1];

                let titleEl = document.createElement("td");
                titleEl.textContent = title;

                let authorEl = document.createElement("td");
                authorEl.textContent = author;

                let editBtn = document.createElement("button");
                editBtn.textContent = "Edit";
                editBtn.addEventListener("click", handleEdit);

                let deleteBtn = document.createElement("button");
                deleteBtn.textContent = "Delete";
                deleteBtn.addEventListener("click", handleDelete);

                let buttonsEl = document.createElement("td");
                buttonsEl.appendChild(editBtn);
                buttonsEl.appendChild(deleteBtn);

                let tr = document.createElement("tr");
                tr.id = id;
                tr.appendChild(titleEl);
                tr.appendChild(authorEl);
                tr.appendChild(buttonsEl);

                tableBody.appendChild(tr);
            });
        })
        .catch((err) => {
            console.log(err);
        });
}

function handleEdit(e) {

    formHeading.textContent = "Edit FORM";
    submitBtn.textContent = "Edit";

    form.id = e.target.parentElement.parentElement.id;

    fetch(`${url}/${e.target.parentNode.parentNode.id}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        }
    })
        .then((res) => {
            if(res.status !== 200) {
                throw new Error('Wrong status code!');
            }

            return res.json();
        })
        .then((data) => {
            let titleInput = form.querySelector('input[name="title"]');
            titleInput.value = data.title;

            let authorInput = form.querySelector('input[name="author"]');
            authorInput.value = data.author;

        })
        .catch((err) => {
            console.log(err);
        })
}

function handleDelete(e) {
    const id = e.target.parentElement.parentElement.id;

    fetch(`${url}/${id}`, {
        method: "DELETE",
    }).then(() => {
        handleLoadBooks();
    });
}
